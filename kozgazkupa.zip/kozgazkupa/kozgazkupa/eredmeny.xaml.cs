﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace kozgazkupa
{
   
    /// <summary>
    /// Interaction logic for eredmeny.xaml
    /// </summary>
    public partial class eredmeny : Window
    {
        public eredmeny()
        {
            InitializeComponent();

            try
            {

                string[] csapatok1 = File.ReadAllLines("csapatok.txt");
                var nev = csapatok1.Select(sor => sor.Split("\t")[0]).ToList();
                myComboBoxx.ItemsSource = nev;

                string[] csapatok = File.ReadAllLines("csapatok.txt");
                var nevek = csapatok.Select(sor => sor.Split("\t" )[0]).ToList();
                myComboBox.ItemsSource = nevek;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a fájl beolvasásakor: " + ex.Message);
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Itt kezelheted, ha a felhasználó választott valamit
            // Például kiírhatod a kiválasztott elemet:
            if (myComboBox.SelectedItem != null)
            {
                string valasztott = myComboBox.SelectedItem.ToString();
                
            }
        }


        private void ComboBox_SelectionChanged1(object sender, SelectionChangedEventArgs e)
        {
            // Itt kezelheted, ha a felhasználó választott valamit
            // Például kiírhatod a kiválasztott elemet:
            if (myComboBox.SelectedItem != null)
            {
                string valasztott = myComboBox.SelectedItem.ToString();
                
            }
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {

            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

     
    }
}
