﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace kozgazkupa
{

    

    /// <summary>
    /// Interaction logic for csapat.xaml
    /// </summary>
    public partial class csapat : Window
    {
      
        public csapat()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        List<csap_oszt> csapatok = new List<csap_oszt>();

        private void Felvitel_Click(object sender, RoutedEventArgs e)
        {
            csap_oszt j1 = new csap_oszt("", 0, 0);
            j1.Nev = nev1.Text;
            j1.Id = int.Parse(id.Text);
            j1.Szam = int.Parse(szam.Text);

            csapatok.Add(j1);

            FileStream f = new FileStream("csapatok.txt", FileMode.Append);

            StreamWriter iras = new StreamWriter(f) ;

            iras.WriteLine(nev1.Text + "\t" + id.Text + "\t" + szam.Text + "\n");

            iras.Close();
            f.Close();
            
            

        }
    }
}
