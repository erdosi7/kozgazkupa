﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kozgazkupa
{
    internal class jat_oszt
    {
        string nev;
        int kor;
        string poszt;

        public jat_oszt(string nev, int kor, string poszt)
        {
            this.Nev = nev;
            this.Kor = kor;
            this.Poszt = poszt;
        }

        public string Nev { get => nev; set => nev = value; }
        public int Kor { get => kor; set => kor = value; }
        public string Poszt { get => poszt; set => poszt = value; }
    }
}
