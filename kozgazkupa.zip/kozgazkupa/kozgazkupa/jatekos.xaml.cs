﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace kozgazkupa
{
    /// <summary>
    /// Interaction logic for jatekos.xaml
    /// </summary>
    public partial class jatekos : Window
    {
        public jatekos()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        List<jat_oszt> jatekosok = new List<jat_oszt>();
        private void Felvi_Click(object sender, RoutedEventArgs e)
        {
            jat_oszt j1 = new jat_oszt("",0,"");
            j1.Nev = nev.Text;
            j1.Kor = int.Parse(kor.Text); ;
            j1.Poszt = poszt.Text;

            jatekosok.Add(j1);

            FileStream f = new FileStream("jatekosok.txt", FileMode.Append);

            StreamWriter iras = new StreamWriter(f);

            iras.Write(nev.Text + "\t" + kor.Text + "\t" + poszt.Text + "\n");

            iras.Close();
            f.Close();

        }
    }
}
