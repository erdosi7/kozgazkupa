﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Xml.Linq;

namespace kozgazkupa
{
    internal class csap_oszt
    {
        string nev;
        int id;
        int szam;

        public csap_oszt(string nev, int id, int szam)
        {
            this.Nev = nev;
            this.Id = id;
            this.Szam = szam;
        }

        public string Nev { get => nev; set => nev = value; }
        public int Id { get => id; set => id = value; }
        public int Szam { get => szam; set => szam = value; }
    }
}
